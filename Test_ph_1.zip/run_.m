
% run for different diameters and mesh densities

clear all 

! rm -r out_results/
! mkdir out_results/

% problem = 4000; 
% eval(['!sed -i ',char(39),'32s/.*/problem = ',num2str(problem),...
%     ' /',char(39),' Main.m']);

L = 150000 ; 
% eval(['!sed -i ',char(39),'3s/.*/L = ',num2str(L,10),...
%      '; /',char(39),' in/3SolidFib.geo']);
% for ii__ = [11 31 61]
for l_ = [L/500 L/1000 L/3000 L/6000]

% for df__ = [0.01 0.05 0.1 0.5 1 ]
for eps_ = [ 0.5 1 2 3 4]
    
% for nf__ = [ 200 500 1000 10000 20000 ]
% for nf__ = [  1000  ]

%     nf__
    
% dd__ = find(df__==[0.01 0.05 0.1 0.5 1 ]) ; 
% 
% tend = fliplr([2000 1000 500 200 100]);    
% tend(dd__)
    
% dd__ = find(nf__==[ 200 500 1000 10000 20000 ]) ; 


eval(['!sed -i ',char(39),'17s/.*/l_ =   ',num2str(l_),...
    '; /',char(39),' Input_.m']);
    
eval(['!sed -i ',char(39),'555s/.*/    eps_ =  ',num2str(eps_*l_),...
    '; /',char(39),' Interface_friction_phasefield.m']);
    
% eval(['!sed -i ',char(39),'23s/.*/    tEnd  =  ',num2str(tend(dd__)),...
%     '; /',char(39),' in/problems/input52.m']);


% eval(['!sed -i ',char(39),'188s/.*/Fibs = Fibs(1:',num2str(nf__),...
%     ',:); /',char(39),' MeshGenerator/Fiber3D.m']);

save ll.mat l_ eps_ 

Interface_friction_phasefield ; 

load ll.mat l_ eps_ 

% eval(['! cp out/RR_.log out_results/RR_',num2str(ii__),'_',num2str(dd__),'.log']);

eval(['! cp -r out out_results/out',num2str(l_),'_',num2str(eps_)]);


% pause
% end

end

end

